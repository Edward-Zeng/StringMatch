
from distutils.core import setup

setup(name="StringCluster", version="0.1", description="A module used to cluster a set of text strings without certain meaning", author="Edward-Zeng", py_modules=['StringCluster.StringCluster','StringCluster.StringMatch'])